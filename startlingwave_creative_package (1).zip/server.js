require('dotenv').config();
const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default: f})=>f(...args));
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '')));

const payments = [];

const DAR_ENV = process.env.DAR_ENV || 'sandbox';
const DAR_CONSUMER_KEY = process.env.DAR_CONSUMER_KEY || '';
const DAR_CONSUMER_SECRET = process.env.DAR_CONSUMER_SECRET || '';
const DAR_SHORTCODE = process.env.DAR_SHORTCODE || '';
const DAR_PASSKEY = process.env.DAR_PASSKEY || '';
const CALLBACK_BASE = process.env.CALLBACK_BASE || '';

async function getToken(){
  const auth = Buffer.from(`${DAR_CONSUMER_KEY}:${DAR_CONSUMER_SECRET}`).toString('base64');
  const url = DAR_ENV==='sandbox'?'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials':'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  const res = await fetch(url,{headers:{Authorization:`Basic ${auth}`}});
  const j=await res.json(); if(j.access_token) return j.access_token; throw new Error('No token');
}

app.post('/api/mpesa/stkpush', async (req,res)=>{
  try{
    const {amount,phone} = req.body;
    if(!amount||!phone) return res.status(400).json({error:'missing'});
    const token = await getToken();
    const timestamp = new Date().toISOString().replace(/[-:TZ.]/g,'').slice(0,14);
    const password = Buffer.from(`${DAR_SHORTCODE}${DAR_PASSKEY}${timestamp}`).toString('base64');
    const cleaned = phone.replace(/\\D/g,'').replace(/^0/,'254');
    const payload = {BusinessShortCode:DAR_SHORTCODE,Password:password,Timestamp:timestamp,TransactionType:"CustomerPayBillOnline",Amount:amount,PartyA:cleaned,PartyB:DAR_SHORTCODE,PhoneNumber:cleaned,CallBackURL:(CALLBACK_BASE?CALLBACK_BASE+'/api/mpesa/callback':''),AccountReference:'StartlingWave',TransactionDesc:'Payment'};
    const endpoint = DAR_ENV==='sandbox'?'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest':'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
    const r = await fetch(endpoint,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const j = await r.json(); payments.unshift({id:Date.now(),req:payload,resp:j}); return res.json(j);
  }catch(e){ console.error(e); return res.status(500).json({error:String(e)}); }
});

app.post('/api/mpesa/callback',(req,res)=>{ payments.unshift({id:Date.now(),callback:req.body}); console.log('callback',req.body); res.json({ResultCode:0,ResultDesc:'Accepted'}); });
app.get('/api/payments',(req,res)=>res.json(payments));

const port = process.env.PORT||3000; app.listen(port,()=>console.log('server',port));